const makeConfig = require( './core/packages/webpack/src/config' );
module.exports = makeConfig( __dirname, false );
